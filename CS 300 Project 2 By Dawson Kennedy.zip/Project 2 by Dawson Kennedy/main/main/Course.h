// ============================================================
//Author: Dawson Kennedy
//Date: April 13, 2024
//Class: CS-300-R4807 DSA: Analysis and Design 24EW4
//Project: 7-1 Project Two
// ============================================================


#ifndef COURSE_H
#define COURSE_H

#include <string>
#include <vector>
#include <iostream>

class Course {
	public:
		std::string courseNumber;
		std::string courseName;
		std::vector<std::string> prerequisites;

		// constructor to initialize a Course object with attributes
		Course(const std::string& num, const std::string& name, const std::vector<std::string> prereqs)
			: courseNumber(num), courseName(name), prerequisites(prereqs) {}

		// Method to print course details formatted for display
		void printCourseInfo() const {
			std::cout << "Course Number: " << courseNumber << "\n";
			std::cout << "Course Name: " << courseName << "\n";
			if (!prerequisites.empty()) {
				std::cout << "Prerequisites: ";
				for (const auto& prereq : prerequisites) {
					std::cout << prereq << " ";

				}

				std::cout << "\n";

			}

			else {
				std::cout << "No prerequisites. \n";

			}

		}
};

// COURSE_H
#endif