// ============================================================
//Author: Dawson Kennedy
//Date: April 13, 2024
//Class: CS-300-R4807 DSA: Analysis and Design 24EW4
//Project: 7-1 Project Two
// ============================================================


#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include "Course.h"

// function declarations for utility and core
std::vector<std::string> split(const std::string& s, char delimiter);
bool loadCourses(const std::string& filename, std::vector<Course>& courses);
void printAllCourses(const std::vector<Course>& courses);
void printCourseDetails(const std::vector<Course>& courses, const std::string& courseNumber);

int main() {
	// Store all course data
	std::vector<Course> courses;
	// File name for loading course
	std::string filename;
	// User menu choice
	int choice;

	do {
		// Display the menu options
		std::cout << "\n1. Load Data Structure\n"
				  << "2. Print Course List\n"
				  << "3. Print Course\n"
				  << "4. Exit\n"
				  << "Enter your choice: ";

		// Input validation for choice
		if (!(std::cin >> choice)) {
			// Clear error flag
			std::cin.clear();
			// Ignore bad input
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "invalid input. Please enter a number.\n";
			continue;

		}

		// Handling differnt menu options
		switch (choice) {
		case 1:
			std::cout << "Enter filename: ";
			std::cin >> filename;
			if (loadCourses(filename, courses)) {
				std::cout << "course loaded successfully.\n";

			}

			else {
				std::cout << "Failed to load courses. Check file path and format.\n";

			}

			break;
		case 2:
			// Check if courses are loaded before attempting to print
			if (courses.empty()) {
				std::cout << "No courses loaded. Please load course first.\n";

			}

			else {
				printAllCourses(courses);

			}

			break;
		case 3:
			// Check if courses are loaded before attempting to print details
			if (courses.empty()) {
				std::cout << "No courses loaded. Please load course first.\n";

			}

			else {
				std::cout << "Enter course number: ";
				// Reuse file name variable to get course number
				std::cin >> filename;
				printCourseDetails(courses, filename);

			}

			break;
		case 4:
			// Exit the program
			std::cout << "Exiting program.\n";
			return 0;
		default:
			// Handle incorrect choice input
			std::cout << "Invalid choice. Please enter a number between 1 and 4.\n";
			break;

		}

	}

	// Loop the menu until the user chooses to exit
	while (true);
}


// Split a string by a delimiter and return a vector of tokens
std::vector<std::string> split(const std::string& s, char delimiter) {
	std::vector<std::string> tokens;
	std::string token;
	std::istringstream tokenStream(s);
	while (getline(tokenStream, token, delimiter)) {
		tokens.push_back(token);
	}

	return tokens;

}

// Load course from a specified file into a vector of Course objects
bool loadCourses(const std::string& filename, std::vector<Course>& courses) {
	std::ifstream file(filename);
	if (!file.is_open()) {
		std::cerr << "Unable to open file: " << filename << std::endl;
		return false;
	}
	std::string line;
	while (getline(file, line)) {
		std::vector<std::string> tokens = split(line, ',');
		// Ensure there is at least a course number
		if (tokens.size() < 2) continue;
		std::string courseNumber = tokens[0];
		std::string courseName = tokens[1];
		std::vector<std::string> prerequisites(tokens.begin() + 2, tokens.end());
		courses.push_back(Course(courseNumber, courseName, prerequisites));

	}

	file.close();
	return true;

}

// Print all course's details
void printAllCourses(const std::vector<Course>& courses) {
	for (const auto& course : courses) {
		course.printCourseInfo();
		std::cout << std::endl;
	}
}

// Print specific course details by course number
void printCourseDetails(const std::vector<Course>& courses, const std::string& courseNumber) {
	for (const auto& course : courses) {
		if (course.courseNumber == courseNumber) {
			course.printCourseInfo();
			return;
		}
	}

	std::cout << "Course not found.\n";

}