#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  1 12:47:07 2024

@author: phillipkenned_snhu
"""

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""
    
    def __init__(self, username, password, hostname, port, dbname):
        """
        Initialize the MongoClient to access the MongoDB databse.
        Connect to the databse using provided credentials and host details.
        
        """

        try:
            # Cronnect to the MongoDB server
            self.client = MongoClient(f'mongodb://{username}:{password}@{hostname}:{port}')
            # Selecting the database
            self.database = self.client[dbname]
        except ConnectionFailure as e:
            print(f"Could not connect to MongoDB: {e}")
    
    def create(self, data):
        """
        Insert a new document into the 'animals' collection.
        :param data: A dictionary containing the data to be inserted.
        :return: True if the insert was successful, False othersise.

        """
        
        try:
            if data:
                # Insert the data into the collection
                insert_result = self.database.animals.insert_one(data)
                return insert_result.acknowledged
            else:
                raise ValueError("Nothing to save, data parameter is empty")
        except Exception as e:
            print(f"An error occurred while inserting data: {e}")
            return False
            
    def read(self, query):
        """
        Query for documents in the 'animals' collection.
        :param query: A dictionary representing the query to filter documents.
        :return: A list of documents that much the query.

        """
        
        try:
            if query is None:
                query = {}
                # Query the collection
            cursor = self.database.animals.find(query, {"_id": False})
            return list(cursor)
        except Exception as e:
            print(f"An error occurred while reading data: {e}")
            return []
    
    def update(self, query, new_values):
        """
        Update documents in the 'aniamals' collection.
        :param query: A dictionary representing the query to filter documents.
        :parm new_values: A dictionary containing the fields to be updated.
        :return: The number of documents modified.

        """
        
        try:
            if query and new_values:
                # Update the documents that match the query
                update_result = self.database.animals.update_many(query, {'$set': new_values})
                return update_result.modified_count
            else:
                raise ValueError("Query and new_values parameters cannot be empty")
        except Exception as e:
            print(f"An error occurred while updating data: {e}")
            return 0
    
    def delete(self, query):
        """
        Delete documents from the 'animals' collection.
        :param query: A dictionary representing the query to filter documents.
        :return: The number of documents deleted.

        """
        
        try:
            if query:
                # Delete the documents that match the query
                delete_result = self.database.animals.delete_many(query)
                return delete_result.deleted_count
            else:
                raise ValueError("Nothing to delete, query parameter is empty")
        except Exception as e:
            print(f"An error occured while deleting data: {e}")
            return 0